def count_in_list(lst: list, a) -> int:
    return lst.count(a)

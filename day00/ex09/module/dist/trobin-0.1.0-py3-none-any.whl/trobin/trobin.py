def count_in_list(lst, a):
    return lst.count(a)